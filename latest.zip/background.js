import{e as E,S as c,b as R,c as P,a as p,t as T}from"./assets/chunk-CTGQDKAB.js";const U="https://public-api.shiphero.com/graphql",C="https://public-api.shiphero.com/auth/refresh",q=15e3,S=2,M=500,v=5*60*1e3;async function A(e){const t=new AbortController,n=setTimeout(()=>t.abort(),q);let o;try{o=await fetch(C,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({refresh_token:e}),signal:t.signal})}catch(s){throw E(s)}finally{clearTimeout(n)}if(o.status===401||o.status===403)throw new c("auth_invalid","This ShipHero refresh token is invalid or has been revoked. Please reconnect your account.",{requiresReauth:!0});if(!o.ok)throw R(o.status);let r;try{r=await o.json()}catch{throw new c("unknown","ShipHero returned an unreadable response while connecting.")}if(!r.access_token||!r.expires_in)throw new c("unknown","ShipHero did not return a valid access token.");return{accessToken:r.access_token,expiresAt:Date.now()+r.expires_in*1e3,refreshToken:e}}function x(e){return new Promise(t=>setTimeout(t,e))}const m=new Map;async function B(e,t,n){const o=new AbortController,r=setTimeout(()=>o.abort(),q);let s;try{s=await fetch(U,{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${n}`},body:JSON.stringify({query:e,variables:t}),signal:o.signal})}catch(i){throw E(i)}finally{clearTimeout(r)}if(!s.ok)throw R(s.status);let a;try{a=await s.json()}catch{throw new c("unknown","ShipHero returned an unreadable response.")}if(a.errors&&a.errors.length>0)throw P(a.errors.map(i=>i.message));if(!a.data)throw new c("unknown","ShipHero returned an empty response.");return a.data}function z(e){return e instanceof c&&(e.kind==="network"||e.kind==="timeout")}async function $(e,t,n){let o;for(let r=0;r<=S;r++)try{return await B(e,t,n)}catch(s){if(o=s,!z(s)||r===S)throw s;await x(M*2**r)}throw o}function _(e,t,n){const o=JSON.stringify({query:e,variables:t}),r=m.get(o);if(r)return r;const s=$(e,t,n).finally(()=>{m.delete(o)});return m.set(o,s),s}const O=`
  id
  legacy_id
  order_number
  partner_order_id
  fulfillment_status
  order_date
  required_ship_date
  email
  profile
  shipping_address { name address1 address2 city state zip country phone }
  billing_address { name address1 address2 city state zip country phone }
  shipping_lines { carrier method title price }
  line_items(first: 100) {
    edges {
      node {
        id
        sku
        product_name
        quantity
        quantity_allocated
        quantity_shipped
        fulfillment_status
      }
    }
  }
  shipments {
    edges {
      node {
        id
        warehouse_id
        shipped_date
        shipping_labels { tracking_number carrier shipping_method tracking_url }
      }
    }
  }
`,Y=`
  query OrdersByNumber($orderNumber: String!) {
    orders(order_number: $orderNumber) {
      edges {
        node {
          ${O}
        }
      }
    }
  }
`,K=`
  query OrderById($id: String!) {
    order(id: $id) {
      ${O}
    }
  }
`;function F(e){return e?{name:e.name??null,line1:e.address1??null,line2:e.address2??null,city:e.city??null,state:e.state??null,zip:e.zip??null,country:e.country??null,phone:e.phone??null}:null}function Q(e){var n;const t=(n=e.shipping_labels)==null?void 0:n[0];return{id:e.id??null,warehouseId:e.warehouse_id??null,trackingNumber:(t==null?void 0:t.tracking_number)??null,carrier:(t==null?void 0:t.carrier)??null,shippingMethod:(t==null?void 0:t.shipping_method)??null,trackingUrl:(t==null?void 0:t.tracking_url)??null}}function b(e){var i,l,h,d,f,k,g,w;const t=((l=(i=e.line_items)==null?void 0:i.edges)==null?void 0:l.map(u=>u.node))??[],n=((d=(h=e.shipments)==null?void 0:h.edges)==null?void 0:d.map(u=>u.node))??[],o=(f=e.shipping_lines)==null?void 0:f[0],r=n[0],s=(k=r==null?void 0:r.shipping_labels)==null?void 0:k[0],a=!e.order_date||!e.shipping_address||!e.line_items||t.length===0;return{id:e.id,legacyId:e.legacy_id??null,orderNumber:e.order_number,orderDate:e.order_date??null,requiredShipDate:e.required_ship_date??null,fulfillmentStatus:e.fulfillment_status??null,customerName:((g=e.shipping_address)==null?void 0:g.name)??((w=e.billing_address)==null?void 0:w.name)??null,shippingAddress:F(e.shipping_address),shippingMethod:(o==null?void 0:o.method)??(s==null?void 0:s.shipping_method)??null,carrier:(o==null?void 0:o.carrier)??(s==null?void 0:s.carrier)??null,warehouse:(r==null?void 0:r.warehouse_id)??null,lineItems:t.map(u=>({id:u.id,sku:u.sku,productName:u.product_name??null,quantityOrdered:u.quantity,quantityAllocated:u.quantity_allocated??null,quantityShipped:u.quantity_shipped??null,fulfillmentStatus:u.fulfillment_status??null})),shipments:n.map(Q),hasIncompleteData:a}}async function L(e,t){var s,a;const n=e.trim();if(!n)throw new c("unknown","Enter an order ID or order number to search.");const r=((a=(s=(await _(Y,{orderNumber:n},t)).orders)==null?void 0:s.edges)==null?void 0:a.map(i=>i.node))??[];if(r.length>0)return r.map(b);try{const i=await _(K,{id:n},t);if(i.order)return[b(i.order)]}catch(i){if(i instanceof c&&i.requiresReauth)throw i}return[]}const W=`
  query ProductsBySku($sku: String!) {
    products(sku: $sku) {
      edges {
        node {
          id
          legacy_id
          account_id
          sku
          name
          barcode
          kit
          kit_build
          images { src position }
          kit_components { id sku quantity }
          warehouse_products {
            warehouse_id
            warehouse { id identifier }
            on_hand
            available
            allocated
            backorder
            sell_ahead
            reserve_inventory
            non_sellable_quantity
          }
        }
      }
    }
  }
`,j=`
  query ProductLocationsBySku($sku: String!) {
    products(sku: $sku) {
      edges {
        node {
          sku
          warehouse_products {
            warehouse_id
            locations {
              edges {
                node { id name pickable sellable quantity }
              }
            }
          }
        }
      }
    }
  }
`;function G(e,t){var o,r;const n=e.warehouse_id??((o=e.warehouse)==null?void 0:o.id)??null;return{warehouseId:n,warehouseName:((r=e.warehouse)==null?void 0:r.identifier)??n,onHand:e.on_hand??null,available:e.available??null,allocated:e.allocated??null,backorder:e.backorder??null,sellAhead:e.sell_ahead??null,pickable:e.reserve_inventory!=null&&e.on_hand!=null?e.on_hand-e.reserve_inventory:null,locations:n&&t.get(n)||[]}}function J(e,t){var r,s;const n=e.warehouse_products??[],o=!e.name||n.length===0;return{id:e.id,sku:e.sku,name:e.name??null,barcode:e.barcode??null,accountId:e.account_id??null,imageUrl:((s=(r=e.images)==null?void 0:r[0])==null?void 0:s.src)??null,isKit:e.kit===!0,kitComponents:(e.kit_components??[]).map(a=>({sku:a.sku,quantity:a.quantity})),warehouseInventory:n.map(a=>G(a,t)),hasIncompleteData:o}}async function V(e,t){var o,r;const n=new Map;try{const s=await _(j,{sku:e},t);for(const a of((o=s.products)==null?void 0:o.edges)??[])for(const i of a.node.warehouse_products??[]){const l=i.warehouse_id;if(!l)continue;const h=(((r=i.locations)==null?void 0:r.edges)??[]).map(d=>({id:d.node.id??null,name:d.node.name??null,pickable:d.node.pickable??null,quantity:d.node.quantity??null}));n.set(l,h)}}catch{}return n}async function X(e,t){var a,i;const n=e.trim();if(!n)throw new c("unknown","Enter a SKU to search.");const[o,r]=await Promise.all([_(W,{sku:n},t),V(n,t)]);return(((i=(a=o.products)==null?void 0:a.edges)==null?void 0:i.map(l=>l.node))??[]).map(l=>J(l,r))}async function N(){const t=(await chrome.storage.local.get(p.auth))[p.auth];return Z(t)?t:null}async function I(e){await chrome.storage.local.set({[p.auth]:e})}async function H(){await chrome.storage.local.remove(p.auth)}function Z(e){if(!e||typeof e!="object")return!1;const t=e;return typeof t.accessToken=="string"&&typeof t.refreshToken=="string"&&typeof t.expiresAt=="number"}const D="shiphero-token-refresh";function ee(e){const t=T(e);return{kind:t.kind,message:t.message,requiresReauth:t.requiresReauth}}async function y(){const e=await N();if(!e)throw new c("auth_expired","Connect your ShipHero account to continue.",{requiresReauth:!0});if(Date.now()<e.expiresAt-v)return e.accessToken;try{const t=await A(e.refreshToken);return await I(t),t.accessToken}catch(t){const n=T(t);throw n.requiresReauth&&await H(),n}}async function te(e){try{switch(e.type){case"CONNECT":{const t=await A(e.refreshToken);return await I(t),{ok:!0,data:{connected:!0}}}case"DISCONNECT":return await H(),{ok:!0,data:{connected:!1}};case"GET_AUTH_STATUS":return{ok:!0,data:{connected:await N()!==null}};case"SEARCH_ORDERS":{const t=await y();return{ok:!0,data:await L(e.query,t)}}case"SEARCH_PRODUCTS":{const t=await y();return{ok:!0,data:await X(e.sku,t)}}default:return e}}catch(t){return{ok:!1,error:ee(t)}}}chrome.runtime.onMessage.addListener((e,t,n)=>(te(e).then(n),!0));chrome.runtime.onInstalled.addListener(()=>{chrome.alarms.create(D,{periodInMinutes:15})});chrome.alarms.onAlarm.addListener(e=>{e.name===D&&y().catch(()=>{})});
