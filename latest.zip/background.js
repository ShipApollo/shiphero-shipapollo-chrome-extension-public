import{S as c,e as O,b as f,c as U,a as d,t as y}from"./assets/chunk-C7EVx-jd.js";const M="https://public-api.shiphero.com/graphql",v="https://public-api.shiphero.com/auth/refresh",x="https://public-api.shiphero.com/auth/token",A=15e3,R=2,B=500,z=5*60*1e3;async function N(e,t,r){const o=new AbortController,s=setTimeout(()=>o.abort(),A);let n;try{n=await fetch(e,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(t),signal:o.signal})}catch(i){throw O(i)}finally{clearTimeout(s)}if(n.status===401||n.status===403)throw new c("auth_invalid",r,{requiresReauth:!0});if(!n.ok)throw f(n.status);let a;try{a=await n.json()}catch{throw new c("unknown","ShipHero returned an unreadable response while connecting.")}if(!a.access_token||!a.expires_in)throw new c("unknown","ShipHero did not return a valid access token.");return a}async function $(e){const t=await N(v,{refresh_token:e},"This ShipHero session is invalid or has been revoked. Please reconnect your account.");return{accessToken:t.access_token,expiresAt:Date.now()+t.expires_in*1e3,refreshToken:t.refresh_token??e}}async function I(e,t){const r=await N(x,{username:e,password:t},"Incorrect ShipHero email or password.");if(!r.refresh_token)throw new c("unknown","ShipHero did not return a refresh token for this login.");return{accessToken:r.access_token,expiresAt:Date.now()+r.expires_in*1e3,refreshToken:r.refresh_token}}function Y(e){return new Promise(t=>setTimeout(t,e))}const m=new Map;async function K(e,t,r){const o=new AbortController,s=setTimeout(()=>o.abort(),A);let n;try{n=await fetch(M,{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${r}`},body:JSON.stringify({query:e,variables:t}),signal:o.signal})}catch(i){throw O(i)}finally{clearTimeout(s)}if(n.status===401||n.status===403)throw f(n.status);let a;try{a=await n.json()}catch{a=void 0}if(a!=null&&a.errors&&a.errors.length>0)throw U(a.errors.map(i=>i.message));if(!n.ok)throw f(n.status);if(!(a!=null&&a.data))throw new c("unknown","ShipHero returned an empty response.");return a.data}function F(e){return e instanceof c&&(e.kind==="network"||e.kind==="timeout")}async function Q(e,t,r){let o;for(let s=0;s<=R;s++)try{return await K(e,t,r)}catch(n){if(o=n,!F(n)||s===R)throw n;await Y(B*2**s)}throw o}function _(e,t,r){const o=JSON.stringify({query:e,variables:t}),s=m.get(o);if(s)return s;const n=Q(e,t,r).finally(()=>{m.delete(o)});return m.set(o,n),n}const H=`
  id
  legacy_id
  order_number
  partner_order_id
  fulfillment_status
  order_date
  required_ship_date
  email
  profile
  shipping_address { name address1 address2 city state zip country phone }
  billing_address { name address1 address2 city state zip country phone }
  shipping_lines { carrier method title price }
  line_items(first: 100) {
    edges {
      node {
        id
        sku
        product_name
        quantity
        quantity_allocated
        quantity_shipped
        fulfillment_status
      }
    }
  }
  shipments {
    edges {
      node {
        id
        warehouse_id
        shipped_date
        shipping_labels { tracking_number carrier shipping_method tracking_url }
      }
    }
  }
`,L=`
  query OrdersByNumber($orderNumber: String!) {
    orders(order_number: $orderNumber) {
      edges {
        node {
          ${H}
        }
      }
    }
  }
`,W=`
  query OrderById($id: String!) {
    order(id: $id) {
      ${H}
    }
  }
`;function j(e){return e?{name:e.name??null,line1:e.address1??null,line2:e.address2??null,city:e.city??null,state:e.state??null,zip:e.zip??null,country:e.country??null,phone:e.phone??null}:null}function G(e){var r;const t=(r=e.shipping_labels)==null?void 0:r[0];return{id:e.id??null,warehouseId:e.warehouse_id??null,trackingNumber:(t==null?void 0:t.tracking_number)??null,carrier:(t==null?void 0:t.carrier)??null,shippingMethod:(t==null?void 0:t.shipping_method)??null,trackingUrl:(t==null?void 0:t.tracking_url)??null}}function q(e){var i,l,p,h,S,E,T,b;const t=((l=(i=e.line_items)==null?void 0:i.edges)==null?void 0:l.map(u=>u.node))??[],r=((h=(p=e.shipments)==null?void 0:p.edges)==null?void 0:h.map(u=>u.node))??[],o=(S=e.shipping_lines)==null?void 0:S[0],s=r[0],n=(E=s==null?void 0:s.shipping_labels)==null?void 0:E[0],a=!e.order_date||!e.shipping_address||!e.line_items||t.length===0;return{id:e.id,legacyId:e.legacy_id??null,orderNumber:e.order_number,orderDate:e.order_date??null,requiredShipDate:e.required_ship_date??null,fulfillmentStatus:e.fulfillment_status??null,customerName:((T=e.shipping_address)==null?void 0:T.name)??((b=e.billing_address)==null?void 0:b.name)??null,shippingAddress:j(e.shipping_address),shippingMethod:(o==null?void 0:o.method)??(n==null?void 0:n.shipping_method)??null,carrier:(o==null?void 0:o.carrier)??(n==null?void 0:n.carrier)??null,warehouse:(s==null?void 0:s.warehouse_id)??null,lineItems:t.map(u=>({id:u.id,sku:u.sku,productName:u.product_name??null,quantityOrdered:u.quantity,quantityAllocated:u.quantity_allocated??null,quantityShipped:u.quantity_shipped??null,fulfillmentStatus:u.fulfillment_status??null})),shipments:r.map(G),hasIncompleteData:a}}async function J(e,t){var n,a;const r=e.trim();if(!r)throw new c("unknown","Enter an order ID or order number to search.");const s=((a=(n=(await _(L,{orderNumber:r},t)).orders)==null?void 0:n.edges)==null?void 0:a.map(i=>i.node))??[];if(s.length>0)return s.map(q);try{const i=await _(W,{id:r},t);if(i.order)return[q(i.order)]}catch(i){if(i instanceof c&&i.requiresReauth)throw i}return[]}const V=`
  query ProductsBySku($sku: String!) {
    products(sku: $sku) {
      edges {
        node {
          id
          legacy_id
          account_id
          sku
          name
          barcode
          kit
          kit_build
          images { src position }
          kit_components { id sku quantity }
          warehouse_products {
            warehouse_id
            warehouse { id identifier }
            on_hand
            available
            allocated
            backorder
            sell_ahead
            reserve_inventory
            non_sellable_quantity
          }
        }
      }
    }
  }
`,X=`
  query ProductLocationsBySku($sku: String!) {
    products(sku: $sku) {
      edges {
        node {
          sku
          warehouse_products {
            warehouse_id
            locations {
              edges {
                node { id name pickable sellable quantity }
              }
            }
          }
        }
      }
    }
  }
`;function Z(e,t){var o,s;const r=e.warehouse_id??((o=e.warehouse)==null?void 0:o.id)??null;return{warehouseId:r,warehouseName:((s=e.warehouse)==null?void 0:s.identifier)??r,onHand:e.on_hand??null,available:e.available??null,allocated:e.allocated??null,backorder:e.backorder??null,sellAhead:e.sell_ahead??null,pickable:e.reserve_inventory!=null&&e.on_hand!=null?e.on_hand-e.reserve_inventory:null,locations:r&&t.get(r)||[]}}function ee(e,t){var s,n;const r=e.warehouse_products??[],o=!e.name||r.length===0;return{id:e.id,sku:e.sku,name:e.name??null,barcode:e.barcode??null,accountId:e.account_id??null,imageUrl:((n=(s=e.images)==null?void 0:s[0])==null?void 0:n.src)??null,isKit:e.kit===!0,kitComponents:(e.kit_components??[]).map(a=>({sku:a.sku,quantity:a.quantity})),warehouseInventory:r.map(a=>Z(a,t)),hasIncompleteData:o}}async function te(e,t){var o,s;const r=new Map;try{const n=await _(X,{sku:e},t);for(const a of((o=n.products)==null?void 0:o.edges)??[])for(const i of a.node.warehouse_products??[]){const l=i.warehouse_id;if(!l)continue;const p=(((s=i.locations)==null?void 0:s.edges)??[]).map(h=>({id:h.node.id??null,name:h.node.name??null,pickable:h.node.pickable??null,quantity:h.node.quantity??null}));r.set(l,p)}}catch{}return r}async function re(e,t){var a,i;const r=e.trim();if(!r)throw new c("unknown","Enter a SKU to search.");const[o,s]=await Promise.all([_(V,{sku:r},t),te(r,t)]);return(((i=(a=o.products)==null?void 0:a.edges)==null?void 0:i.map(l=>l.node))??[]).map(l=>ee(l,s))}async function D(){const t=(await chrome.storage.local.get(d.auth))[d.auth];return ne(t)?t:null}async function k(e){await chrome.storage.local.set({[d.auth]:e})}async function w(){await chrome.storage.local.remove(d.auth)}function ne(e){if(!e||typeof e!="object")return!1;const t=e;return typeof t.accessToken=="string"&&typeof t.refreshToken=="string"&&typeof t.expiresAt=="number"}async function oe(){const t=(await chrome.storage.local.get(d.credentials))[d.credentials];return ae(t)?t:null}async function se(e){await chrome.storage.local.set({[d.credentials]:e})}async function P(){await chrome.storage.local.remove(d.credentials)}function ae(e){if(!e||typeof e!="object")return!1;const t=e;return typeof t.username=="string"&&typeof t.password=="string"}const C="shiphero-token-refresh";function ie(e){const t=y(e);return{kind:t.kind,message:t.message,requiresReauth:t.requiresReauth}}async function g(){const e=await D();if(!e)throw new c("auth_expired","Connect your ShipHero account to continue.",{requiresReauth:!0});if(Date.now()<e.expiresAt-z)return e.accessToken;try{const t=await $(e.refreshToken);return await k(t),t.accessToken}catch(t){if(!y(t).requiresReauth)throw t;const r=await oe();if(!r)throw await w(),t;try{const o=await I(r.username,r.password);return await k(o),o.accessToken}catch(o){const s=y(o);throw s.requiresReauth&&(await w(),await P()),s}}}async function ue(e){try{switch(e.type){case"CONNECT":{const t=await I(e.username,e.password);return await k(t),await se({username:e.username,password:e.password}),{ok:!0,data:{connected:!0}}}case"DISCONNECT":return await w(),await P(),{ok:!0,data:{connected:!1}};case"GET_AUTH_STATUS":return{ok:!0,data:{connected:await D()!==null}};case"SEARCH_ORDERS":{const t=await g();return{ok:!0,data:await J(e.query,t)}}case"SEARCH_PRODUCTS":{const t=await g();return{ok:!0,data:await re(e.sku,t)}}default:return e}}catch(t){return{ok:!1,error:ie(t)}}}chrome.runtime.onMessage.addListener((e,t,r)=>(ue(e).then(r),!0));chrome.runtime.onInstalled.addListener(()=>{chrome.alarms.create(C,{periodInMinutes:15})});chrome.alarms.onAlarm.addListener(e=>{e.name===C&&g().catch(()=>{})});
