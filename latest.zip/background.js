import{S as c,e as q,b as O,c as U,a as d,t as f}from"./assets/chunk-DHGeNJt4.js";const M="https://public-api.shiphero.com/graphql",x="https://public-api.shiphero.com/auth/refresh",v="https://public-api.shiphero.com/auth/token",A=15e3,b=2,B=500,z=5*60*1e3;async function N(e,t,n){const r=new AbortController,o=setTimeout(()=>r.abort(),A);let s;try{s=await fetch(e,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(t),signal:r.signal})}catch(i){throw q(i)}finally{clearTimeout(o)}if(s.status===401||s.status===403)throw new c("auth_invalid",n,{requiresReauth:!0});if(!s.ok)throw O(s.status);let a;try{a=await s.json()}catch{throw new c("unknown","ShipHero returned an unreadable response while connecting.")}if(!a.access_token||!a.expires_in)throw new c("unknown","ShipHero did not return a valid access token.");return a}async function $(e){const t=await N(x,{refresh_token:e},"This ShipHero session is invalid or has been revoked. Please reconnect your account.");return{accessToken:t.access_token,expiresAt:Date.now()+t.expires_in*1e3,refreshToken:t.refresh_token??e}}async function I(e,t){const n=await N(v,{username:e,password:t},"Incorrect ShipHero email or password.");if(!n.refresh_token)throw new c("unknown","ShipHero did not return a refresh token for this login.");return{accessToken:n.access_token,expiresAt:Date.now()+n.expires_in*1e3,refreshToken:n.refresh_token}}function Y(e){return new Promise(t=>setTimeout(t,e))}const m=new Map;async function K(e,t,n){const r=new AbortController,o=setTimeout(()=>r.abort(),A);let s;try{s=await fetch(M,{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${n}`},body:JSON.stringify({query:e,variables:t}),signal:r.signal})}catch(i){throw q(i)}finally{clearTimeout(o)}if(!s.ok)throw O(s.status);let a;try{a=await s.json()}catch{throw new c("unknown","ShipHero returned an unreadable response.")}if(a.errors&&a.errors.length>0)throw U(a.errors.map(i=>i.message));if(!a.data)throw new c("unknown","ShipHero returned an empty response.");return a.data}function F(e){return e instanceof c&&(e.kind==="network"||e.kind==="timeout")}async function Q(e,t,n){let r;for(let o=0;o<=b;o++)try{return await K(e,t,n)}catch(s){if(r=s,!F(s)||o===b)throw s;await Y(B*2**o)}throw r}function _(e,t,n){const r=JSON.stringify({query:e,variables:t}),o=m.get(r);if(o)return o;const s=Q(e,t,n).finally(()=>{m.delete(r)});return m.set(r,s),s}const H=`
  id
  legacy_id
  order_number
  partner_order_id
  fulfillment_status
  order_date
  required_ship_date
  email
  profile
  shipping_address { name address1 address2 city state zip country phone }
  billing_address { name address1 address2 city state zip country phone }
  shipping_lines { carrier method title price }
  line_items(first: 100) {
    edges {
      node {
        id
        sku
        product_name
        quantity
        quantity_allocated
        quantity_shipped
        fulfillment_status
      }
    }
  }
  shipments {
    edges {
      node {
        id
        warehouse_id
        shipped_date
        shipping_labels { tracking_number carrier shipping_method tracking_url }
      }
    }
  }
`,L=`
  query OrdersByNumber($orderNumber: String!) {
    orders(order_number: $orderNumber) {
      edges {
        node {
          ${H}
        }
      }
    }
  }
`,W=`
  query OrderById($id: String!) {
    order(id: $id) {
      ${H}
    }
  }
`;function j(e){return e?{name:e.name??null,line1:e.address1??null,line2:e.address2??null,city:e.city??null,state:e.state??null,zip:e.zip??null,country:e.country??null,phone:e.phone??null}:null}function G(e){var n;const t=(n=e.shipping_labels)==null?void 0:n[0];return{id:e.id??null,warehouseId:e.warehouse_id??null,trackingNumber:(t==null?void 0:t.tracking_number)??null,carrier:(t==null?void 0:t.carrier)??null,shippingMethod:(t==null?void 0:t.shipping_method)??null,trackingUrl:(t==null?void 0:t.tracking_url)??null}}function R(e){var i,l,p,h,g,S,E,T;const t=((l=(i=e.line_items)==null?void 0:i.edges)==null?void 0:l.map(u=>u.node))??[],n=((h=(p=e.shipments)==null?void 0:p.edges)==null?void 0:h.map(u=>u.node))??[],r=(g=e.shipping_lines)==null?void 0:g[0],o=n[0],s=(S=o==null?void 0:o.shipping_labels)==null?void 0:S[0],a=!e.order_date||!e.shipping_address||!e.line_items||t.length===0;return{id:e.id,legacyId:e.legacy_id??null,orderNumber:e.order_number,orderDate:e.order_date??null,requiredShipDate:e.required_ship_date??null,fulfillmentStatus:e.fulfillment_status??null,customerName:((E=e.shipping_address)==null?void 0:E.name)??((T=e.billing_address)==null?void 0:T.name)??null,shippingAddress:j(e.shipping_address),shippingMethod:(r==null?void 0:r.method)??(s==null?void 0:s.shipping_method)??null,carrier:(r==null?void 0:r.carrier)??(s==null?void 0:s.carrier)??null,warehouse:(o==null?void 0:o.warehouse_id)??null,lineItems:t.map(u=>({id:u.id,sku:u.sku,productName:u.product_name??null,quantityOrdered:u.quantity,quantityAllocated:u.quantity_allocated??null,quantityShipped:u.quantity_shipped??null,fulfillmentStatus:u.fulfillment_status??null})),shipments:n.map(G),hasIncompleteData:a}}async function J(e,t){var s,a;const n=e.trim();if(!n)throw new c("unknown","Enter an order ID or order number to search.");const o=((a=(s=(await _(L,{orderNumber:n},t)).orders)==null?void 0:s.edges)==null?void 0:a.map(i=>i.node))??[];if(o.length>0)return o.map(R);try{const i=await _(W,{id:n},t);if(i.order)return[R(i.order)]}catch(i){if(i instanceof c&&i.requiresReauth)throw i}return[]}const V=`
  query ProductsBySku($sku: String!) {
    products(sku: $sku) {
      edges {
        node {
          id
          legacy_id
          account_id
          sku
          name
          barcode
          kit
          kit_build
          images { src position }
          kit_components { id sku quantity }
          warehouse_products {
            warehouse_id
            warehouse { id identifier }
            on_hand
            available
            allocated
            backorder
            sell_ahead
            reserve_inventory
            non_sellable_quantity
          }
        }
      }
    }
  }
`,X=`
  query ProductLocationsBySku($sku: String!) {
    products(sku: $sku) {
      edges {
        node {
          sku
          warehouse_products {
            warehouse_id
            locations {
              edges {
                node { id name pickable sellable quantity }
              }
            }
          }
        }
      }
    }
  }
`;function Z(e,t){var r,o;const n=e.warehouse_id??((r=e.warehouse)==null?void 0:r.id)??null;return{warehouseId:n,warehouseName:((o=e.warehouse)==null?void 0:o.identifier)??n,onHand:e.on_hand??null,available:e.available??null,allocated:e.allocated??null,backorder:e.backorder??null,sellAhead:e.sell_ahead??null,pickable:e.reserve_inventory!=null&&e.on_hand!=null?e.on_hand-e.reserve_inventory:null,locations:n&&t.get(n)||[]}}function ee(e,t){var o,s;const n=e.warehouse_products??[],r=!e.name||n.length===0;return{id:e.id,sku:e.sku,name:e.name??null,barcode:e.barcode??null,accountId:e.account_id??null,imageUrl:((s=(o=e.images)==null?void 0:o[0])==null?void 0:s.src)??null,isKit:e.kit===!0,kitComponents:(e.kit_components??[]).map(a=>({sku:a.sku,quantity:a.quantity})),warehouseInventory:n.map(a=>Z(a,t)),hasIncompleteData:r}}async function te(e,t){var r,o;const n=new Map;try{const s=await _(X,{sku:e},t);for(const a of((r=s.products)==null?void 0:r.edges)??[])for(const i of a.node.warehouse_products??[]){const l=i.warehouse_id;if(!l)continue;const p=(((o=i.locations)==null?void 0:o.edges)??[]).map(h=>({id:h.node.id??null,name:h.node.name??null,pickable:h.node.pickable??null,quantity:h.node.quantity??null}));n.set(l,p)}}catch{}return n}async function ne(e,t){var a,i;const n=e.trim();if(!n)throw new c("unknown","Enter a SKU to search.");const[r,o]=await Promise.all([_(V,{sku:n},t),te(n,t)]);return(((i=(a=r.products)==null?void 0:a.edges)==null?void 0:i.map(l=>l.node))??[]).map(l=>ee(l,o))}async function D(){const t=(await chrome.storage.local.get(d.auth))[d.auth];return re(t)?t:null}async function y(e){await chrome.storage.local.set({[d.auth]:e})}async function k(){await chrome.storage.local.remove(d.auth)}function re(e){if(!e||typeof e!="object")return!1;const t=e;return typeof t.accessToken=="string"&&typeof t.refreshToken=="string"&&typeof t.expiresAt=="number"}async function oe(){const t=(await chrome.storage.local.get(d.credentials))[d.credentials];return ae(t)?t:null}async function se(e){await chrome.storage.local.set({[d.credentials]:e})}async function P(){await chrome.storage.local.remove(d.credentials)}function ae(e){if(!e||typeof e!="object")return!1;const t=e;return typeof t.username=="string"&&typeof t.password=="string"}const C="shiphero-token-refresh";function ie(e){const t=f(e);return{kind:t.kind,message:t.message,requiresReauth:t.requiresReauth}}async function w(){const e=await D();if(!e)throw new c("auth_expired","Connect your ShipHero account to continue.",{requiresReauth:!0});if(Date.now()<e.expiresAt-z)return e.accessToken;try{const t=await $(e.refreshToken);return await y(t),t.accessToken}catch(t){if(!f(t).requiresReauth)throw t;const n=await oe();if(!n)throw await k(),t;try{const r=await I(n.username,n.password);return await y(r),r.accessToken}catch(r){const o=f(r);throw o.requiresReauth&&(await k(),await P()),o}}}async function ue(e){try{switch(e.type){case"CONNECT":{const t=await I(e.username,e.password);return await y(t),await se({username:e.username,password:e.password}),{ok:!0,data:{connected:!0}}}case"DISCONNECT":return await k(),await P(),{ok:!0,data:{connected:!1}};case"GET_AUTH_STATUS":return{ok:!0,data:{connected:await D()!==null}};case"SEARCH_ORDERS":{const t=await w();return{ok:!0,data:await J(e.query,t)}}case"SEARCH_PRODUCTS":{const t=await w();return{ok:!0,data:await ne(e.sku,t)}}default:return e}}catch(t){return{ok:!1,error:ie(t)}}}chrome.runtime.onMessage.addListener((e,t,n)=>(ue(e).then(n),!0));chrome.runtime.onInstalled.addListener(()=>{chrome.alarms.create(C,{periodInMinutes:15})});chrome.alarms.onAlarm.addListener(e=>{e.name===C&&w().catch(()=>{})});
